"use client";
import { useState } from "react";
import { apiFetch } from "../lib/api";

export default function LoginPage() {
  const [email, setEmail] = useState("employee@example.com");
  const [password, setPassword] = useState("Password123!");
  const [error, setError] = useState("");

  async function onLogin(e) {
    e.preventDefault();
    setError("");
    try {
      const data = await apiFetch("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password })
      });
      localStorage.setItem("token", data.token);
      window.location.href = "/dashboard";
    } catch (e) {
      setError(String(e.message || e));
    }
  }

  return (
    <div style={{ minHeight: "100vh", background: "#000", display: "grid", placeItems: "center" }}>
      <form onSubmit={onLogin} style={{ width: 380, padding: 24, borderRadius: 16, background: "#111", color: "#fff" }}>
        <h1 style={{ fontSize: 22, marginBottom: 12 }}>Solidarités Soudan Movement Tracker Login</h1>

        <label>Email</label>
        <input value={email} onChange={(e)=>setEmail(e.target.value)} style={{ width:"100%", padding:10, margin:"6px 0 12px", borderRadius:10 }} />

        <label>Password</label>
        <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} style={{ width:"100%", padding:10, margin:"6px 0 12px", borderRadius:10 }} />

        {error && <p style={{ color: "#ff4d4d" }}>{error}</p>}

        <button style={{ width:"100%", padding:12, borderRadius:12, background:"#d7261e", color:"#fff", fontWeight:700 }}>
          Sign in
        </button>

        <p style={{ marginTop: 12, color:"#aaa", fontSize: 12 }}>
          Try roles: employee@example.com, hr@example.com, logistics@example.com, cd@example.com, admin@example.com
        </p>
      </form>
    </div>
  );
}
