export default function Home() {
  return (
    <div style={{ minHeight:"100vh", background:"#000", color:"#fff", display:"grid", placeItems:"center", padding:24 }}>
      <div style={{ maxWidth: 560 }}>
        <h1 style={{ margin:0, fontSize:32 }}>Solidarités Soudan Movement Tracker</h1>
        <p style={{ color:"#bbb" }}>
          Movement Tracking System for Logistics, HR, and CD – Solidarités Soudan
        </p>
        <a href="/login" style={{ display:"inline-block", background:"#d7261e", padding:"12px 16px", borderRadius:12, color:"#fff", textDecoration:"none", fontWeight:700 }}>
          Go to Login
        </a>
      </div>
    </div>
  );
}
