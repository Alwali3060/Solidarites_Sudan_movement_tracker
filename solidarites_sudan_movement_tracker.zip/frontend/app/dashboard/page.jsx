"use client";
import { useEffect, useState } from "react";
import Nav from "../components/Nav";
import { apiFetch } from "../lib/api";

function Card({ title, children }) {
  return (
    <div style={{ background:"#111", borderRadius:16, padding:16, border:"1px solid #1f1f1f" }}>
      <div style={{ fontWeight:800, marginBottom:10 }}>{title}</div>
      {children}
    </div>
  );
}

export default function Dashboard() {
  const [me, setMe] = useState(null);
  const [my, setMy] = useState([]);
  const [pending, setPending] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) window.location.href = "/login";

    apiFetch("/api/auth/me").then(d => setMe(d.user));

    apiFetch("/api/requests/my").then(d => setMy(d.items)).catch(() => {});
  }, []);

  useEffect(() => {
    if (!me) return;
    const stage =
      me.role === "HR" ? "HR" :
      me.role === "LOGISTICS" ? "LOGISTICS" :
      me.role === "CD" ? "CD" : null;

    if (!stage) return;
    apiFetch(`/api/requests/pending?stage=${stage}`).then(d => setPending(d.items)).catch(() => {});
  }, [me]);

  if (!me) return <div style={{ background:"#000", color:"#fff", minHeight:"100vh", padding:24 }}>Loading...</div>;

  const role = me.role;

  return (
    <div style={{ minHeight:"100vh", background:"#000", color:"#fff", padding:24 }}>
      <Nav />

      <div style={{ display:"grid", gap:16, gridTemplateColumns:"repeat(auto-fit, minmax(280px, 1fr))" }}>
        <Card title="Quick actions">
          {role === "EMPLOYEE" && (
            <a href="/requests/new" style={{ display:"inline-block", background:"#d7261e", padding:"10px 14px", borderRadius:12, color:"#fff", textDecoration:"none", fontWeight:800 }}>
              + New Request
            </a>
          )}
          {role !== "EMPLOYEE" && (
            <p style={{ color:"#bbb", margin:0 }}>
              Review pending requests for your role.
            </p>
          )}
        </Card>

        <Card title="My requests">
          {my.length === 0 ? <p style={{ color:"#bbb", margin:0 }}>No requests yet.</p> : (
            <div style={{ display:"grid", gap:10 }}>
              {my.slice(0,5).map(r => (
                <a key={r.id} href={`/requests/${r.id}`} style={{ color:"#fff", textDecoration:"none" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", background:"#0b0b0b", padding:10, borderRadius:12, border:"1px solid #1f1f1f" }}>
                    <span style={{ fontWeight:700 }}>{r.requestNumber}</span>
                    <span style={{ color:"#bbb" }}>{r.status}</span>
                  </div>
                </a>
              ))}
            </div>
          )}
        </Card>

        {role !== "EMPLOYEE" && (
          <Card title={`Pending (${role})`}>
            {pending.length === 0 ? <p style={{ color:"#bbb", margin:0 }}>No pending items.</p> : (
              <div style={{ display:"grid", gap:10 }}>
                {pending.slice(0,6).map(r => (
                  <a key={r.id} href={`/requests/${r.id}`} style={{ color:"#fff", textDecoration:"none" }}>
                    <div style={{ background:"#0b0b0b", padding:10, borderRadius:12, border:"1px solid #1f1f1f" }}>
                      <div style={{ fontWeight:800 }}>{r.requestNumber}</div>
                      <div style={{ color:"#bbb", fontSize:12 }}>{r.requestType} — {r.destination}</div>
                      <div style={{ color:"#aaa", fontSize:12 }}>By: {r.requester?.fullName} ({r.requester?.staffId})</div>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </Card>
        )}
      </div>

      {role !== "EMPLOYEE" && (
        <div style={{ marginTop:16, color:"#aaa", fontSize:12 }}>
          Tip: Open a request to approve/reject, assign vehicle/driver (Logistics), upload files, or add timeline events.
        </div>
      )}
    </div>
  );
}
