"use client";
import { useEffect, useState } from "react";
import Nav from "../../components/Nav";
import { apiFetch } from "../../lib/api";

function isoFromLocal(value) {
  if (!value) return "";
  const d = new Date(value);
  return d.toISOString();
}

export default function NewRequest() {
  const [me, setMe] = useState(null);
  const [form, setForm] = useState({
    requestType: "STAFF",
    purpose: "",
    destination: "",
    startAtLocal: "",
    endAtLocal: "",
    emergency: false
  });
  const [msg, setMsg] = useState("");

  useEffect(() => {
    apiFetch("/api/auth/me").then(d => {
      setMe(d.user);
      if (d.user.role !== "EMPLOYEE" && d.user.role !== "ADMIN") {
        window.location.href = "/dashboard";
      }
    }).catch(() => window.location.href = "/login");
  }, []);

  function update(k, v) { setForm(prev => ({ ...prev, [k]: v })); }

  async function submit(e) {
    e.preventDefault();
    setMsg("");
    try {
      const payload = {
        requestType: form.requestType,
        purpose: form.purpose,
        destination: form.destination,
        startAt: isoFromLocal(form.startAtLocal),
        endAt: isoFromLocal(form.endAtLocal),
        emergency: form.emergency
      };
      const data = await apiFetch("/api/requests", { method:"POST", body: JSON.stringify(payload) });
      window.location.href = `/requests/${data.id}`;
    } catch (e) {
      setMsg(String(e.message || e));
    }
  }

  if (!me) return <div style={{ background:"#000", color:"#fff", minHeight:"100vh", padding:24 }}>Loading...</div>;

  return (
    <div style={{ minHeight:"100vh", background:"#000", color:"#fff", padding:24 }}>
      <Nav />
      <h1 style={{ fontSize:24, marginBottom:14 }}>New Movement Request</h1>

      <form onSubmit={submit} style={{ maxWidth:640, background:"#111", borderRadius:16, padding:16, border:"1px solid #1f1f1f" }}>
        <label>Request Type</label>
        <select value={form.requestType} onChange={(e)=>update("requestType", e.target.value)} style={{ width:"100%", padding:10, borderRadius:10, margin:"6px 0 12px" }}>
          <option value="STAFF">Staff Movement</option>
          <option value="VEHICLE">Vehicle Request</option>
          <option value="ASSET">Asset/Equipment Movement</option>
          <option value="FIELD">Field/Community Assignment (Needs CD)</option>
        </select>

        <label>Purpose</label>
        <textarea value={form.purpose} onChange={(e)=>update("purpose", e.target.value)} style={{ width:"100%", padding:10, borderRadius:10, margin:"6px 0 12px", minHeight:90 }} />

        <label>Destination</label>
        <input value={form.destination} onChange={(e)=>update("destination", e.target.value)} style={{ width:"100%", padding:10, borderRadius:10, margin:"6px 0 12px" }} />

        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap: 12 }}>
          <div>
            <label>Start</label>
            <input type="datetime-local" value={form.startAtLocal} onChange={(e)=>update("startAtLocal", e.target.value)} style={{ width:"100%", padding:10, borderRadius:10, margin:"6px 0 12px" }} />
          </div>
          <div>
            <label>End</label>
            <input type="datetime-local" value={form.endAtLocal} onChange={(e)=>update("endAtLocal", e.target.value)} style={{ width:"100%", padding:10, borderRadius:10, margin:"6px 0 12px" }} />
          </div>
        </div>

        <label style={{ display:"flex", gap:10, alignItems:"center" }}>
          <input type="checkbox" checked={form.emergency} onChange={(e)=>update("emergency", e.target.checked)} />
          Emergency
        </label>

        {msg && <p style={{ color:"#ff4d4d" }}>{msg}</p>}

        <button style={{ marginTop:12, width:"100%", padding:12, borderRadius:12, background:"#d7261e", color:"#fff", fontWeight:800, cursor:"pointer" }}>
          Submit Request
        </button>
      </form>
    </div>
  );
}
