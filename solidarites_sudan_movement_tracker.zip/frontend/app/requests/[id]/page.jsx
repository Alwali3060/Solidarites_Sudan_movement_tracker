"use client";
import { useEffect, useMemo, useState } from "react";
import Nav from "../../components/Nav";
import { API_BASE, apiFetch, getToken } from "../../lib/api";

function Badge({ text }) {
  return <span style={{ display:"inline-block", padding:"6px 10px", borderRadius:999, background:"#222", border:"1px solid #333", color:"#fff", fontSize:12 }}>{text}</span>;
}

function Panel({ title, children }) {
  return (
    <div style={{ background:"#111", borderRadius:16, padding:16, border:"1px solid #1f1f1f" }}>
      <div style={{ fontWeight:900, marginBottom:10 }}>{title}</div>
      {children}
    </div>
  );
}

export default function RequestDetails({ params }) {
  const [me, setMe] = useState(null);
  const [item, setItem] = useState(null);
  const [events, setEvents] = useState([]);
  const [error, setError] = useState("");

  const [approve, setApprove] = useState({ decision: "APPROVED", comment: "" });
  const [statusMove, setStatusMove] = useState("IN_TRANSIT");
  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [assign, setAssign] = useState({ vehicleId: "", driverId: "" });

  const [note, setNote] = useState("");

  const stage = useMemo(() => {
    if (!me || !item) return null;
    if (me.role === "HR") return "HR";
    if (me.role === "LOGISTICS") return "LOGISTICS";
    if (me.role === "CD") return "CD";
    if (me.role === "ADMIN") {
      // admin can act; infer stage from status
      if (item.status === "PENDING_HR") return "HR";
      if (item.status === "PENDING_LOGISTICS") return "LOGISTICS";
      if (item.status === "PENDING_CD") return "CD";
      return null;
    }
    return null;
  }, [me, item]);

  async function refresh() {
    setError("");
    try {
      const d1 = await apiFetch("/api/auth/me");
      setMe(d1.user);
      const d2 = await apiFetch(`/api/requests/${params.id}`);
      setItem(d2.item);
      const d3 = await apiFetch(`/api/requests/${params.id}/tracking-events`);
      setEvents(d3.events);
    } catch (e) {
      setError(String(e.message || e));
    }
  }

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) window.location.href = "/login";
    refresh();
  }, [params.id]);

  useEffect(() => {
    if (!me) return;
    if (me.role === "LOGISTICS" || me.role === "ADMIN") {
      apiFetch("/api/admin/vehicles").then(d => setVehicles(d.vehicles)).catch(() => {});
      apiFetch("/api/admin/drivers").then(d => setDrivers(d.drivers)).catch(() => {});
    }
  }, [me]);

  async function doApprove() {
    if (!stage) return;
    await apiFetch(`/api/requests/${params.id}/approve`, {
      method: "POST",
      body: JSON.stringify({ stage, decision: approve.decision, comment: approve.comment || undefined })
    });
    setApprove({ decision: "APPROVED", comment: "" });
    await refresh();
  }

  async function doAssign() {
    await apiFetch(`/api/requests/${params.id}/assign`, {
      method: "POST",
      body: JSON.stringify({
        vehicleId: assign.vehicleId || null,
        driverId: assign.driverId || null
      })
    });
    await refresh();
  }

  async function changeStatus() {
    await apiFetch(`/api/requests/${params.id}/status`, {
      method: "POST",
      body: JSON.stringify({ status: statusMove })
    });
    await refresh();
  }

  async function addNote() {
    if (!note.trim()) return;
    await apiFetch(`/api/requests/${params.id}/tracking-events`, {
      method: "POST",
      body: JSON.stringify({ eventType: "COMMENT", message: note.trim() })
    });
    setNote("");
    await refresh();
  }

  async function uploadFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    const form = new FormData();
    form.append("file", file);

    const token = getToken();
    const res = await fetch(`${API_BASE}/api/requests/${params.id}/attachments`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: form
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setError(data?.error?.message || data?.error || "Upload failed");
      return;
    }
    await refresh();
  }

  if (error) {
    return <div style={{ background:"#000", color:"#fff", minHeight:"100vh", padding:24 }}>{error}</div>;
  }
  if (!me || !item) {
    return <div style={{ background:"#000", color:"#fff", minHeight:"100vh", padding:24 }}>Loading...</div>;
  }

  const canApprove = Boolean(stage) && ["PENDING_HR","PENDING_LOGISTICS","PENDING_CD"].includes(item.status);

  return (
    <div style={{ minHeight:"100vh", background:"#000", color:"#fff", padding:24 }}>
      <Nav />

      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap: 12, flexWrap:"wrap" }}>
        <div>
          <h1 style={{ fontSize:24, margin:"0 0 6px" }}>{item.requestNumber}</h1>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            <Badge text={item.status} />
            <Badge text={item.requestType} />
            <Badge text={item.emergency ? "EMERGENCY" : "NORMAL"} />
          </div>
        </div>
        <a href="/dashboard" style={{ color:"#fff" }}>Back</a>
      </div>

      <div style={{ marginTop:16, display:"grid", gap:16, gridTemplateColumns:"repeat(auto-fit, minmax(320px, 1fr))" }}>
        <Panel title="Request details">
          <div style={{ color:"#bbb", fontSize: 13, lineHeight: 1.5 }}>
            <div><b style={{ color:"#fff" }}>Requester:</b> {item.requester?.fullName} ({item.requester?.staffId})</div>
            <div><b style={{ color:"#fff" }}>Destination:</b> {item.destination}</div>
            <div><b style={{ color:"#fff" }}>Purpose:</b> {item.purpose}</div>
            <div><b style={{ color:"#fff" }}>Start:</b> {new Date(item.startAt).toLocaleString()}</div>
            <div><b style={{ color:"#fff" }}>End:</b> {new Date(item.endAt).toLocaleString()}</div>
          </div>
        </Panel>

        <Panel title="Approvals">
          {item.approvals?.length ? (
            <div style={{ display:"grid", gap: 10 }}>
              {item.approvals.map(a => (
                <div key={a.id} style={{ background:"#0b0b0b", padding:10, borderRadius:12, border:"1px solid #1f1f1f" }}>
                  <div style={{ fontWeight:900 }}>{a.stage} — {a.decision}</div>
                  <div style={{ color:"#bbb", fontSize: 12 }}>{new Date(a.decidedAt).toLocaleString()}</div>
                  {a.comment && <div style={{ color:"#ddd", marginTop:6 }}>{a.comment}</div>}
                </div>
              ))}
            </div>
          ) : <p style={{ color:"#bbb", margin:0 }}>No approvals yet.</p>}

          {canApprove && (
            <div style={{ marginTop: 12, paddingTop: 12, borderTop:"1px solid #222" }}>
              <div style={{ color:"#bbb", fontSize: 12, marginBottom: 8 }}>You can decide as: <b style={{ color:"#fff" }}>{stage}</b></div>
              <select value={approve.decision} onChange={(e)=>setApprove(p=>({ ...p, decision: e.target.value }))} style={{ width:"100%", padding:10, borderRadius:10 }}>
                <option value="APPROVED">APPROVE</option>
                <option value="REJECTED">REJECT</option>
                <option value="CLARIFICATION">REQUEST CLARIFICATION</option>
              </select>
              <input
                value={approve.comment}
                onChange={(e)=>setApprove(p=>({ ...p, comment: e.target.value }))}
                placeholder="Optional comment"
                style={{ width:"100%", padding:10, borderRadius:10, marginTop: 10 }}
              />
              <button onClick={doApprove} style={{ marginTop:10, width:"100%", padding:12, borderRadius:12, background:"#d7261e", color:"#fff", fontWeight:900, cursor:"pointer" }}>
                Submit Decision
              </button>
            </div>
          )}
        </Panel>

        {(me.role === "LOGISTICS" || me.role === "ADMIN") && (
          <Panel title="Logistics: assign vehicle/driver">
            <div style={{ display:"grid", gap: 10 }}>
              <select value={assign.vehicleId} onChange={(e)=>setAssign(p=>({ ...p, vehicleId: e.target.value }))} style={{ width:"100%", padding:10, borderRadius:10 }}>
                <option value="">No vehicle</option>
                {vehicles.map(v => <option key={v.id} value={v.id}>{v.plateNumber} — {v.model || "Vehicle"}</option>)}
              </select>
              <select value={assign.driverId} onChange={(e)=>setAssign(p=>({ ...p, driverId: e.target.value }))} style={{ width:"100%", padding:10, borderRadius:10 }}>
                <option value="">No driver</option>
                {drivers.map(d => <option key={d.id} value={d.id}>{d.fullName}</option>)}
              </select>
              <button onClick={doAssign} style={{ width:"100%", padding:12, borderRadius:12, background:"#222", color:"#fff", fontWeight:900, border:"1px solid #333", cursor:"pointer" }}>
                Save Assignment
              </button>
            </div>

            <div style={{ marginTop: 10, color:"#bbb", fontSize: 12 }}>
              Latest assignment: {item.assignments?.[0]?.vehicle?.plateNumber || "—"} / {item.assignments?.[0]?.driver?.fullName || "—"}
            </div>
          </Panel>
        )}

        {(me.role === "LOGISTICS" || me.role === "ADMIN") && (
          <Panel title="Movement status">
            <div style={{ display:"grid", gap: 10 }}>
              <select value={statusMove} onChange={(e)=>setStatusMove(e.target.value)} style={{ width:"100%", padding:10, borderRadius:10 }}>
                <option value="IN_TRANSIT">IN_TRANSIT</option>
                <option value="COMPLETED">COMPLETED</option>
                <option value="CLOSED">CLOSED</option>
              </select>
              <button onClick={changeStatus} style={{ width:"100%", padding:12, borderRadius:12, background:"#222", color:"#fff", fontWeight:900, border:"1px solid #333", cursor:"pointer" }}>
                Change Status
              </button>
            </div>
            <p style={{ color:"#aaa", fontSize: 12, marginTop: 10 }}>
              Allowed transitions: APPROVED → IN_TRANSIT → COMPLETED → CLOSED
            </p>
          </Panel>
        )}

        <Panel title="Attachments">
          <input type="file" onChange={uploadFile} />
          <div style={{ marginTop: 12, display:"grid", gap: 10 }}>
            {(item.attachments || []).length === 0 ? <p style={{ color:"#bbb", margin:0 }}>No attachments yet.</p> : (
              item.attachments.map(a => (
                <a key={a.id} href={`${API_BASE}${a.fileUrl}`} target="_blank" rel="noreferrer" style={{ color:"#fff", textDecoration:"none" }}>
                  <div style={{ background:"#0b0b0b", padding:10, borderRadius:12, border:"1px solid #1f1f1f" }}>
                    <div style={{ fontWeight:900 }}>{a.fileName}</div>
                    <div style={{ color:"#bbb", fontSize: 12 }}>{new Date(a.uploadedAt).toLocaleString()}</div>
                  </div>
                </a>
              ))
            )}
          </div>
        </Panel>

        <Panel title="Timeline">
          <div style={{ display:"flex", gap: 10 }}>
            <input
              value={note}
              onChange={(e)=>setNote(e.target.value)}
              placeholder="Add a comment to timeline..."
              style={{ flex:1, padding:10, borderRadius:10 }}
            />
            <button onClick={addNote} style={{ padding:"10px 12px", borderRadius:12, background:"#d7261e", color:"#fff", fontWeight:900, cursor:"pointer" }}>
              Add
            </button>
          </div>

          <div style={{ marginTop: 12, display:"grid", gap: 10 }}>
            {events.length === 0 ? <p style={{ color:"#bbb", margin:0 }}>No timeline events.</p> : (
              events.map(ev => (
                <div key={ev.id} style={{ background:"#0b0b0b", padding:10, borderRadius:12, border:"1px solid #1f1f1f" }}>
                  <div style={{ display:"flex", justifyContent:"space-between", gap: 10, flexWrap:"wrap" }}>
                    <div style={{ fontWeight:900 }}>
                      {ev.eventType}{ev.status ? ` — ${ev.status}` : ""}
                    </div>
                    <div style={{ color:"#bbb", fontSize: 12 }}>
                      {new Date(ev.createdAt).toLocaleString()}
                    </div>
                  </div>
                  {ev.message && <div style={{ color:"#ddd", marginTop: 6 }}>{ev.message}</div>}
                  <div style={{ color:"#888", fontSize: 12, marginTop: 6 }}>
                    By: {ev.createdBy?.fullName || "System"} {ev.createdBy?.role ? `(${ev.createdBy.role})` : ""}
                  </div>
                </div>
              ))
            )}
          </div>
        </Panel>
      </div>
    </div>
  );
}
