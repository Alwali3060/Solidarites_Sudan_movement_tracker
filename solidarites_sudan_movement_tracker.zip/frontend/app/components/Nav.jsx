"use client";
import { apiFetch } from "../lib/api";
import { useEffect, useState } from "react";

export default function Nav() {
  const [me, setMe] = useState(null);

  useEffect(() => {
    apiFetch("/api/auth/me").then(d => setMe(d.user)).catch(() => {});
  }, []);

  function logout() {
    localStorage.removeItem("token");
    window.location.href = "/login";
  }

  return (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom: 16 }}>
      <a href="/dashboard" style={{ color:"#fff", textDecoration:"none", fontWeight:800 }}>Solidarités Soudan Movement Tracker</a>
      <div style={{ display:"flex", gap: 12, alignItems:"center" }}>
        {me && <span style={{ color:"#bbb", fontSize: 12 }}>{me.fullName} — {me.role}</span>}
        <button onClick={logout} style={{ background:"#222", color:"#fff", border:"1px solid #333", padding:"8px 10px", borderRadius:10, cursor:"pointer" }}>
          Logout
        </button>
      </div>
    </div>
  );
}
