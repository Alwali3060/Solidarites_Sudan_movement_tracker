# Solidarités Soudan – Movement Tracking System

This system is designed specifically for **Solidarités Soudan** to manage:
- Staff movements
- Vehicle & asset tracking
- Field & community deployments

## Validation Flow
1. Employee submits request
2. HR validation
3. Logistics validation
4. CD validation (field activities only)

## Core Values
- Accountability
- Transparency
- Staff safety
- Operational efficiency

---
Developed for humanitarian field operations.
