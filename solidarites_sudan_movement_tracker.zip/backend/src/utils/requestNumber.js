export function makeRequestNumber(seq) {
  const year = new Date().getFullYear();
  return `SS-${year}-${String(seq).padStart(6, "0")}`;
}
