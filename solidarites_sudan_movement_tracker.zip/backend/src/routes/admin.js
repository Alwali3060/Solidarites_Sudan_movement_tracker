import express from "express";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = express.Router();

router.get("/vehicles", requireAuth, requireRole("LOGISTICS","ADMIN"), async (req, res) => {
  const vehicles = await prisma.vehicle.findMany({ orderBy: { plateNumber: "asc" } });
  res.json({ vehicles });
});

router.get("/drivers", requireAuth, requireRole("LOGISTICS","ADMIN"), async (req, res) => {
  const drivers = await prisma.driver.findMany({ orderBy: { fullName: "asc" } });
  res.json({ drivers });
});

export default router;
