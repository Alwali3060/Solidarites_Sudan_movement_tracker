import express from "express";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import { prisma } from "../prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { makeRequestNumber } from "../utils/requestNumber.js";

const router = express.Router();

const requestSchema = z.object({
  requestType: z.enum(["STAFF","VEHICLE","ASSET","FIELD"]),
  purpose: z.string().min(5),
  destination: z.string().min(2),
  startAt: z.string().datetime(),
  endAt: z.string().datetime(),
  emergency: z.boolean().optional().default(false),
});

async function nextSeq() {
  const count = await prisma.request.count();
  return count + 1;
}

function needsCD(requestType) {
  return requestType === "FIELD";
}

// Multer setup
const uploadDir = process.env.UPLOAD_DIR || "uploads";
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(process.cwd(), uploadDir));
  },
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}_${safe}`);
  }
});
const upload = multer({ storage });

// Create request (employee)
router.post("/", requireAuth, async (req, res) => {
  const parsed = requestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const seq = await nextSeq();
  const requestNumber = makeRequestNumber(seq);

  const created = await prisma.request.create({
    data: {
      requestNumber,
      requesterId: req.user.id,
      requestType: parsed.data.requestType,
      purpose: parsed.data.purpose,
      destination: parsed.data.destination,
      startAt: new Date(parsed.data.startAt),
      endAt: new Date(parsed.data.endAt),
      emergency: parsed.data.emergency,
      status: "PENDING_HR",
    }
  });

  await prisma.trackingEvent.create({
    data: {
      requestId: created.id,
      eventType: "STATUS_CHANGE",
      status: "PENDING_HR",
      message: "Request submitted and pending HR review.",
      createdById: req.user.id
    }
  });

  res.status(201).json(created);
});

// My requests
router.get("/my", requireAuth, async (req, res) => {
  const items = await prisma.request.findMany({
    where: { requesterId: req.user.id },
    orderBy: { createdAt: "desc" }
  });
  res.json({ items });
});

// Pending by stage (role dashboards)
router.get("/pending", requireAuth, async (req, res) => {
  const stage = String(req.query.stage || "");
  const stageToStatus = {
    HR: "PENDING_HR",
    LOGISTICS: "PENDING_LOGISTICS",
    CD: "PENDING_CD",
  };
  const status = stageToStatus[stage];
  if (!status) return res.status(400).json({ error: "stage must be HR|LOGISTICS|CD" });

  // basic role protection
  if (stage === "HR" && !["HR","ADMIN"].includes(req.user.role)) return res.status(403).json({ error: "Forbidden" });
  if (stage === "LOGISTICS" && !["LOGISTICS","ADMIN"].includes(req.user.role)) return res.status(403).json({ error: "Forbidden" });
  if (stage === "CD" && !["CD","ADMIN"].includes(req.user.role)) return res.status(403).json({ error: "Forbidden" });

  const items = await prisma.request.findMany({
    where: { status },
    include: { requester: { select: { fullName: true, staffId: true, email: true } } },
    orderBy: { createdAt: "asc" }
  });
  res.json({ items });
});

// Request details
router.get("/:id", requireAuth, async (req, res) => {
  const id = req.params.id;
  const item = await prisma.request.findUnique({
    where: { id },
    include: {
      requester: { select: { fullName: true, staffId: true, email: true } },
      approvals: { orderBy: { decidedAt: "asc" } },
      attachments: { orderBy: { uploadedAt: "desc" } },
      assignments: { include: { vehicle: true, driver: true }, orderBy: { assignedAt: "desc" } },
    }
  });
  if (!item) return res.status(404).json({ error: "Not found" });

  // simple access rule: requester or staff roles
  const privileged = ["HR","LOGISTICS","CD","ADMIN"].includes(req.user.role);
  if (!privileged && item.requesterId !== req.user.id) return res.status(403).json({ error: "Forbidden" });

  res.json({ item });
});

// Approve/reject (HR/LOGISTICS/CD)
const approveSchema = z.object({
  stage: z.enum(["HR","LOGISTICS","CD"]),
  decision: z.enum(["APPROVED","REJECTED","CLARIFICATION"]),
  comment: z.string().optional(),
});

router.post("/:id/approve", requireAuth, async (req, res) => {
  const parsed = approveSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const { stage, decision, comment } = parsed.data;

  // role checks per stage
  const okRole =
    (stage === "HR" && ["HR","ADMIN"].includes(req.user.role)) ||
    (stage === "LOGISTICS" && ["LOGISTICS","ADMIN"].includes(req.user.role)) ||
    (stage === "CD" && ["CD","ADMIN"].includes(req.user.role));

  if (!okRole) return res.status(403).json({ error: "Forbidden" });

  const item = await prisma.request.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  // ensure request is at correct status
  const expected =
    stage === "HR" ? "PENDING_HR" :
    stage === "LOGISTICS" ? "PENDING_LOGISTICS" :
    "PENDING_CD";

  if (item.status !== expected && req.user.role !== "ADMIN") {
    return res.status(400).json({ error: `Request is not in ${expected}` });
  }

  await prisma.approval.create({
    data: {
      requestId: item.id,
      stage,
      decidedById: req.user.id,
      decision,
      comment: comment || null,
    }
  });

  // compute new status
  let newStatus = item.status;

  if (decision === "REJECTED") newStatus = "REJECTED";
  if (decision === "CLARIFICATION") newStatus = expected; // stays pending
  if (decision === "APPROVED") {
    if (stage === "HR") newStatus = "PENDING_LOGISTICS";
    if (stage === "LOGISTICS") newStatus = needsCD(item.requestType) ? "PENDING_CD" : "APPROVED";
    if (stage === "CD") newStatus = "APPROVED";
  }

  const updated = await prisma.request.update({
    where: { id: item.id },
    data: { status: newStatus }
  });

  await prisma.trackingEvent.create({
    data: {
      requestId: item.id,
      eventType: "STATUS_CHANGE",
      status: newStatus,
      message: `${stage} decision: ${decision}${comment ? ` — ${comment}` : ""}`,
      createdById: req.user.id
    }
  });

  res.json({ item: updated });
});

// Logistics: assign vehicle/driver
const assignSchema = z.object({
  vehicleId: z.string().uuid().optional().nullable(),
  driverId: z.string().uuid().optional().nullable(),
});

router.post("/:id/assign", requireAuth, requireRole("LOGISTICS","ADMIN"), async (req, res) => {
  const parsed = assignSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const item = await prisma.request.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  const created = await prisma.assignment.create({
    data: {
      requestId: item.id,
      vehicleId: parsed.data.vehicleId || null,
      driverId: parsed.data.driverId || null,
      assignedById: req.user.id
    },
    include: { vehicle: true, driver: true }
  });

  await prisma.trackingEvent.create({
    data: {
      requestId: item.id,
      eventType: "COMMENT",
      message: `Logistics assignment updated: ${created.vehicle?.plateNumber || "No vehicle"} / ${created.driver?.fullName || "No driver"}`,
      createdById: req.user.id
    }
  });

  res.json({ assignment: created });
});

// Change movement status (Logistics/Admin)
const statusSchema = z.object({
  status: z.enum(["IN_TRANSIT","COMPLETED","CLOSED"])
});

router.post("/:id/status", requireAuth, requireRole("LOGISTICS","ADMIN"), async (req, res) => {
  const parsed = statusSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const item = await prisma.request.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  // Only allow transitions from APPROVED -> IN_TRANSIT -> COMPLETED -> CLOSED (simple)
  const allowed =
    (item.status === "APPROVED" && parsed.data.status === "IN_TRANSIT") ||
    (item.status === "IN_TRANSIT" && parsed.data.status === "COMPLETED") ||
    (item.status === "COMPLETED" && parsed.data.status === "CLOSED");

  if (!allowed && req.user.role !== "ADMIN") {
    return res.status(400).json({ error: `Invalid transition from ${item.status} to ${parsed.data.status}` });
  }

  const updated = await prisma.request.update({ where: { id: item.id }, data: { status: parsed.data.status } });

  await prisma.trackingEvent.create({
    data: {
      requestId: item.id,
      eventType: "STATUS_CHANGE",
      status: parsed.data.status,
      message: `Status changed to ${parsed.data.status}`,
      createdById: req.user.id
    }
  });

  res.json({ item: updated });
});

// Tracking events
router.get("/:id/tracking-events", requireAuth, async (req, res) => {
  const id = req.params.id;
  const item = await prisma.request.findUnique({ where: { id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  const privileged = ["HR","LOGISTICS","CD","ADMIN"].includes(req.user.role);
  if (!privileged && item.requesterId !== req.user.id) return res.status(403).json({ error: "Forbidden" });

  const events = await prisma.trackingEvent.findMany({
    where: { requestId: id },
    include: { createdBy: { select: { fullName: true, role: true } } },
    orderBy: { createdAt: "asc" }
  });
  res.json({ events });
});

// Create comment/checkpoint tracking event
const eventSchema = z.object({
  eventType: z.enum(["CHECKPOINT","COMMENT"]),
  message: z.string().min(1),
  latitude: z.number().optional(),
  longitude: z.number().optional(),
});

router.post("/:id/tracking-events", requireAuth, requireRole("LOGISTICS","ADMIN","HR","CD"), async (req, res) => {
  const parsed = eventSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });

  const item = await prisma.request.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  const created = await prisma.trackingEvent.create({
    data: {
      requestId: item.id,
      eventType: parsed.data.eventType,
      message: parsed.data.message,
      latitude: parsed.data.latitude ?? null,
      longitude: parsed.data.longitude ?? null,
      createdById: req.user.id
    }
  });

  res.status(201).json({ event: created });
});

// Upload attachment
router.post("/:id/attachments", requireAuth, upload.single("file"), async (req, res) => {
  const item = await prisma.request.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ error: "Not found" });

  const privileged = ["HR","LOGISTICS","CD","ADMIN"].includes(req.user.role);
  if (!privileged && item.requesterId !== req.user.id) return res.status(403).json({ error: "Forbidden" });

  if (!req.file) return res.status(400).json({ error: "Missing file" });

  const fileUrl = `/uploads/${req.file.filename}`;

  const att = await prisma.requestAttachment.create({
    data: {
      requestId: item.id,
      fileName: req.file.originalname,
      filePath: req.file.path,
      fileUrl,
      mimeType: req.file.mimetype,
      sizeBytes: req.file.size
    }
  });

  await prisma.trackingEvent.create({
    data: {
      requestId: item.id,
      eventType: "ATTACHMENT",
      message: `Attachment uploaded: ${att.fileName}`,
      createdById: req.user.id
    }
  });

  res.status(201).json({ attachment: att, fileUrl });
});

export default router;
