import bcrypt from "bcryptjs";
import { PrismaClient, Role, RequestType, RequestStatus } from "@prisma/client";

const prisma = new PrismaClient();

function reqNum(i) {
  const year = new Date().getFullYear();
  return `SS-${year}-${String(i).padStart(6, "0")}`;
}

async function main() {
  // Departments
  const [hrDept, logDept, cdDept, itDept] = await Promise.all([
    prisma.department.upsert({ where: { name: "HR" }, update: {}, create: { name: "HR" } }),
    prisma.department.upsert({ where: { name: "Logistics" }, update: {}, create: { name: "Logistics" } }),
    prisma.department.upsert({ where: { name: "CD" }, update: {}, create: { name: "CD" } }),
    prisma.department.upsert({ where: { name: "IT" }, update: {}, create: { name: "IT" } }),
  ]);

  const passwordHash = await bcrypt.hash("Password123!", 10);

  const users = [
    { fullName: "Demo Employee", email: "employee@example.com", staffId: "SM001", role: Role.EMPLOYEE, departmentId: itDept.id },
    { fullName: "Demo HR", email: "hr@example.com", staffId: "SM002", role: Role.HR, departmentId: hrDept.id },
    { fullName: "Demo Logistics", email: "logistics@example.com", staffId: "SM003", role: Role.LOGISTICS, departmentId: logDept.id },
    { fullName: "Demo CD", email: "cd@example.com", staffId: "SM004", role: Role.CD, departmentId: cdDept.id },
    { fullName: "Demo Admin", email: "admin@example.com", staffId: "SM005", role: Role.ADMIN, departmentId: itDept.id },
  ];

  for (const u of users) {
    await prisma.user.upsert({
      where: { email: u.email },
      update: { fullName: u.fullName, staffId: u.staffId, role: u.role, departmentId: u.departmentId, passwordHash },
      create: { ...u, passwordHash },
    });
  }

  // Vehicles + Drivers
  await prisma.vehicle.upsert({
    where: { plateNumber: "ABC-123" },
    update: {},
    create: { plateNumber: "ABC-123", model: "Toyota Hilux", isAvailable: true }
  });
  await prisma.vehicle.upsert({
    where: { plateNumber: "XYZ-789" },
    update: {},
    create: { plateNumber: "XYZ-789", model: "Toyota Coaster", isAvailable: true }
  });

  await prisma.driver.upsert({
    where: { id: "00000000-0000-0000-0000-000000000001" },
    update: { fullName: "Driver One", phone: "08000000001", isAvailable: true },
    create: { id: "00000000-0000-0000-0000-000000000001", fullName: "Driver One", phone: "08000000001", isAvailable: true }
  });

  const employee = await prisma.user.findUnique({ where: { email: "employee@example.com" } });

  // Sample request
  const existing = await prisma.request.findFirst({ where: { requestNumber: reqNum(1) } });
  if (!existing && employee) {
    const r = await prisma.request.create({
      data: {
        requestNumber: reqNum(1),
        requesterId: employee.id,
        requestType: RequestType.FIELD,
        purpose: "Community outreach meeting",
        destination: "City Center",
        startAt: new Date(Date.now() + 60 * 60 * 1000),
        endAt: new Date(Date.now() + 6 * 60 * 60 * 1000),
        emergency: false,
        status: RequestStatus.PENDING_HR,
      }
    });

    await prisma.trackingEvent.create({
      data: {
        requestId: r.id,
        eventType: "STATUS_CHANGE",
        status: RequestStatus.PENDING_HR,
        message: "Request created and submitted.",
        createdById: employee.id
      }
    });
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
